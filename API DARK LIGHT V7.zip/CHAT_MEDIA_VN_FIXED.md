# API — Chat Media/VN Fix

Added global media storage at `global_chat_uploads/` and endpoint `POST /api/chat/upload`.
Private media endpoint remains `/api/chat/private/upload`.
Maximum upload size: 150 MB.
Private call/WebRTC signaling routes were not changed.
