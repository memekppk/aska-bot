# API Audio Serve Fix V3

- WAV/M4A/MP3 are served with explicit audio MIME types.
- Media is served inline for in-app playback.
- Global and private upload endpoints remain unchanged apart from media serving headers.
