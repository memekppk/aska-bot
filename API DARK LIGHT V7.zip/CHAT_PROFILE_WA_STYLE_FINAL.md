CHAT PROFILE + WHATSAPP STYLE FINAL API

- All roles can update their own chat profile.
- Added GET /api/chat/profile/user?session_key=...&username=...
- Public profile response contains only username, role, display_name, about and avatar_url.
- Password/session secrets are not returned.
- Global chat messages are enriched from current chat_profile values.
- Existing chat, media, VN and private call/VC endpoints are retained.
